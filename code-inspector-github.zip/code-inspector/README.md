# Code Inspector

A strict three-stage AI agent that checks whether code **does what it's supposed to do** — then stamps a verdict:

```
┌────────────────────────────┐
│          REJECTED          │
│      PURPOSE NOT MET       │
└────────────────────────────┘
```

`APPROVED` · `CONDITIONAL` · `REJECTED` — with numbered findings showing what's wrong, where, and how to fix it.

## How it works

1. **Literal read** — Claude traces what the code *actually* does, ignoring comments and names (they may lie).
2. **Compliance check** — compares actual behavior against the declared purpose. Any deviation, including boundary mismatches like `>` vs `>=`, counts.
3. **Defect hunt** — adversarially searches for edge cases, off-by-one errors, missing error handling, and security holes, assuming hostile inputs.

**Strict mode:** the burden of proof is on the code. `APPROVED` requires zero findings of any severity. Any critical or major finding — or any deviation from the declared purpose — is `REJECTED`.

## Setup

Requires Node.js 18+ and an Anthropic API key.

1. Create a key at [console.anthropic.com](https://console.anthropic.com) (Settings → API keys). Usage is billed per token.
2. Export it:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

No `npm install` needed — the script has zero dependencies.

## Usage

Pass the file and its declared purpose:

```bash
node inspect.mjs src/discount.js "Applies discount codes. SAVE10 gives 10% off any order. SAVE20 gives 20% off orders of \$100 or more. Unknown codes leave the total unchanged."
```

Or put the purpose in a comment near the top of the file, and just pass the file:

```js
// PURPOSE: applies discount codes; SAVE10 = 10% off; SAVE20 = 20% off at $100+; never negative
```

```bash
node inspect.mjs src/discount.js
```

## Exit codes

| Code | Verdict |
|------|---------|
| 0 | APPROVED |
| 1 | CONDITIONAL |
| 2 | REJECTED |
| 3 | Error / bad usage |

Anything other than `0` fails a CI step, so the inspector can gate merges.

## Run it on every pull request

Add your key as a repository secret (repo **Settings → Secrets and variables → Actions → New repository secret**, name it `ANTHROPIC_API_KEY`), then create `.github/workflows/inspect.yml`:

```yaml
name: Code inspection
on: pull_request
jobs:
  inspect:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: node inspect.mjs src/discount.js   # files need a PURPOSE comment
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
```

A `REJECTED` verdict fails the check and blocks the merge.

## Configuration

| Variable | Default | Meaning |
|----------|---------|---------|
| `ANTHROPIC_API_KEY` | — | Required. Your API key. |
| `INSPECTOR_MODEL` | `claude-sonnet-4-6` | Any Claude model name. |

## Notes

- Findings are advisory — the agent is strict but not infallible. Review and test before shipping.
- Files are truncated at 24,000 characters; inspect large codebases file by file.
- Never commit your API key. It belongs in an environment variable or a CI secret (`.env` is already gitignored).
