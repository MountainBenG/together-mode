#!/usr/bin/env node
/**
 * Code Inspector — a strict three-stage AI agent that checks whether code
 * does what it's supposed to do, then stamps APPROVED / CONDITIONAL / REJECTED.
 *
 * Usage:
 *   node inspect.mjs <file> ["what the code is supposed to do"]
 *
 * If the purpose argument is omitted, the first 20 lines of the file are
 * scanned for a comment such as:
 *   // PURPOSE: applies discount codes to a cart total; never goes negative
 *
 * Environment:
 *   ANTHROPIC_API_KEY   required — create one at https://console.anthropic.com
 *   INSPECTOR_MODEL     optional — defaults to "claude-sonnet-4-6"
 *
 * Exit codes:
 *   0 APPROVED · 1 CONDITIONAL · 2 REJECTED · 3 error / bad usage
 */

import { readFile } from "node:fs/promises";
import { basename } from "node:path";

const MODEL = process.env.INSPECTOR_MODEL || "claude-sonnet-4-6";
const API_KEY = process.env.ANTHROPIC_API_KEY;
const MAX_CODE_CHARS = 24000;

// ───────────────────────── terminal paint ─────────────────────────

const tty = !!process.stdout.isTTY;
const paint = (code) => (s) => (tty ? `\u001b[${code}m${s}\u001b[0m` : s);
const bold = paint("1");
const dim = paint("2");
const red = paint("31");
const green = paint("32");
const yellow = paint("33");

const SEV_PAINT = { critical: red, major: yellow, minor: dim };
const SEV_RANK = { critical: 0, major: 1, minor: 2 };

function stampBox(word, sub, color) {
  const inner = Math.max(word.length, sub.length) + 6;
  const center = (t) => {
    const space = inner - t.length;
    const left = Math.floor(space / 2);
    return " ".repeat(left) + t + " ".repeat(space - left);
  };
  return [
    "┌" + "─".repeat(inner) + "┐",
    "│" + center(word) + "│",
    "│" + center(sub) + "│",
    "└" + "─".repeat(inner) + "┘",
  ]
    .map((line) => color(bold(line)))
    .join("\n");
}

const VERDICTS = {
  pass: {
    word: "APPROVED",
    sub: "MEETS DECLARED PURPOSE",
    color: green,
    exit: 0,
    ruling: "Zero findings. Every declared requirement is verifiably implemented.",
  },
  conditional: {
    word: "CONDITIONAL",
    sub: "FINDINGS ATTACHED",
    color: yellow,
    exit: 1,
    ruling: "No deviation from the declared purpose, but minor findings must be resolved before approval.",
  },
  fail: {
    word: "REJECTED",
    sub: "PURPOSE NOT MET",
    color: red,
    exit: 2,
    ruling: "The specimen deviates from its declared purpose or contains serious defects.",
  },
};

// ───────────────────────── Claude API ─────────────────────────

async function callClaude(prompt) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1500,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`API error ${res.status}: ${body.slice(0, 300)}`);
  }
  const data = await res.json();
  return (data.content || [])
    .map((b) => (b.type === "text" ? b.text : ""))
    .filter(Boolean)
    .join("\n");
}

function parseAgentJSON(text) {
  const clean = text.replace(/```json|```/g, "").trim();
  const start = clean.indexOf("{");
  const end = clean.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("Could not parse the agent's JSON report.");
  return JSON.parse(clean.slice(start, end + 1));
}

// ───────────────────────── stage prompts (strict) ─────────────────────────

function stage1Prompt(code) {
  return `You are stage 1 of a code inspection agent. Read the code below and report what it ACTUALLY does when executed. Trace the logic literally. Ignore comments, function names, and apparent intentions — they may be misleading.

CODE:
<code>
${code}
</code>

Respond with ONLY valid JSON, no markdown fences, no preamble, exactly this shape:
{"language":"detected language","summary":"one sentence stating what this code literally does","behaviors":["3 to 6 short statements of literal runtime behavior, covering each branch and condition"]}
Keep every string under 30 words.`;
}

function stage2Prompt(code, purpose, behavior) {
  return `You are stage 2 of a code inspection agent: compliance. Decide whether the code does what it is SUPPOSED to do.

DECLARED PURPOSE (what the code is supposed to do):
${purpose}

STAGE-1 ANALYSIS of actual behavior:
${JSON.stringify(behavior)}

CODE:
<code>
${code}
</code>

List every way the actual behavior deviates from the declared purpose, including missing requirements and boundary conditions (e.g. "over 100" vs "100 or more"). Be strict: any deviation counts, however small. A boundary mismatch is at least "major". A declared requirement with no implementing code is "critical". Respond with ONLY valid JSON, no markdown fences, no preamble:
{"compliance":"match" or "partial" or "mismatch","discrepancies":[{"expected":"what the purpose requires","actual":"what the code does instead","severity":"critical" or "major" or "minor","location":"line number or function name"}]}
Rules: at most 5 discrepancies, most severe first; use an empty array if fully compliant; keep every string under 30 words.`;
}

function stage3Prompt(code, purpose, discrepancies) {
  const already = (discrepancies || []).map((d) => d.expected + " / " + d.actual);
  return `You are stage 3 of a code inspection agent: defect hunting. Adversarially search this code for defects NOT already reported: unhandled edge cases (empty, null/undefined, zero, negative, wrong types, huge inputs), off-by-one errors, error-handling gaps, type coercion bugs, security problems.

DECLARED PURPOSE (context): ${purpose}

ALREADY REPORTED — do not repeat these: ${JSON.stringify(already)}

CODE:
<code>
${code}
</code>

Be strict: assume hostile and messy inputs unless the purpose guarantees clean ones. Missing validation or error handling on anything that can fail is a finding. Every issue must cite a concrete failing input or path — do not invent problems. Respond with ONLY valid JSON, no markdown fences, no preamble:
{"issues":[{"title":"short defect name","severity":"critical" or "major" or "minor","location":"line number or function name","explanation":"why it misbehaves","fix":"the specific change to make"}]}
Rules: at most 5 issues, most severe first; use an empty array if none; keep every string under 30 words.`;
}

// ───────────────────────── verdict (strict) ─────────────────────────

function computeVerdict(compliance, defects) {
  // Strict mode: burden of proof is on the code.
  const all = [...(compliance.discrepancies || []), ...(defects.issues || [])];
  const hasCritical = all.some((f) => f.severity === "critical");
  const hasMajor = all.some((f) => f.severity === "major");
  const deviates =
    compliance.compliance === "mismatch" ||
    compliance.compliance === "partial" ||
    (compliance.discrepancies || []).length > 0;
  if (hasCritical || hasMajor || deviates) return "fail";
  if (all.length > 0) return "conditional";
  return "pass";
}

// ───────────────────────── helpers ─────────────────────────

function extractPurpose(code) {
  for (const line of code.split("\n").slice(0, 20)) {
    const m = line.match(/(?:\/\/|#|\*|--|;|<!--)?\s*purpose\s*:\s*(.+)/i);
    if (m) return m[1].replace(/\*\/\s*$|-->\s*$/, "").trim();
  }
  return null;
}

const USAGE = `Usage: node inspect.mjs <file> ["what the code is supposed to do"]

If no purpose is given, the top of the file is scanned for a comment like:
  // PURPOSE: validates email addresses; must contain exactly one @ ...

Environment:
  ANTHROPIC_API_KEY   required — https://console.anthropic.com
  INSPECTOR_MODEL     optional — default claude-sonnet-4-6

Exit codes: 0 APPROVED · 1 CONDITIONAL · 2 REJECTED · 3 error`;

// ───────────────────────── main ─────────────────────────

async function main() {
  const [, , filePath, purposeArg] = process.argv;

  if (!filePath || filePath === "--help" || filePath === "-h") {
    console.log(USAGE);
    process.exit(filePath ? 0 : 3);
  }
  if (!API_KEY) {
    console.error(
      red("Missing ANTHROPIC_API_KEY.") +
        "\nCreate a key at https://console.anthropic.com (Settings → API keys), then:\n  export ANTHROPIC_API_KEY=sk-ant-..."
    );
    process.exit(3);
  }

  let code;
  try {
    code = await readFile(filePath, "utf8");
  } catch {
    console.error(red(`Cannot read file: ${filePath}`));
    process.exit(3);
  }

  let truncated = false;
  if (code.length > MAX_CODE_CHARS) {
    code = code.slice(0, MAX_CODE_CHARS);
    truncated = true;
  }

  const purpose = (purposeArg || extractPurpose(code) || "").trim();
  if (!purpose) {
    console.error(
      red("No declared purpose.") +
        "\nPass it as the second argument, or add a comment near the top of the file:\n  // PURPOSE: what this code is supposed to do"
    );
    process.exit(3);
  }

  console.log("");
  console.log(bold("CODE INSPECTION · STRICT MODE"));
  console.log(dim("Specimen  ") + basename(filePath) + (truncated ? dim("  (truncated to 24k chars)") : ""));
  console.log(dim("Purpose   ") + purpose);
  console.log(dim("Model     ") + MODEL);
  console.log("");

  const step = async (n, label, fn) => {
    process.stdout.write(dim(`[${n}/3] `) + label + " … ");
    try {
      const out = await fn();
      console.log(green("done"));
      return out;
    } catch (e) {
      console.log(red("failed"));
      throw e;
    }
  };

  const behavior = await step(1, "Reading the logic as written", async () =>
    parseAgentJSON(await callClaude(stage1Prompt(code)))
  );
  const compliance = await step(2, "Checking against declared purpose", async () =>
    parseAgentJSON(await callClaude(stage2Prompt(code, purpose, behavior)))
  );
  const defects = await step(3, "Hunting for defects and edge cases", async () =>
    parseAgentJSON(await callClaude(stage3Prompt(code, purpose, compliance.discrepancies)))
  );

  const findings = [
    ...(compliance.discrepancies || []).map((d) => ({ kind: "mismatch", ...d })),
    ...(defects.issues || []).map((i) => ({ kind: "defect", ...i })),
  ].sort((a, b) => (SEV_RANK[a.severity] ?? 3) - (SEV_RANK[b.severity] ?? 3));

  const v = VERDICTS[computeVerdict(compliance, defects)];

  console.log("\n" + stampBox(v.word, v.sub, v.color) + "\n");
  console.log(v.ruling + "\n");

  console.log(bold("WHAT IT ACTUALLY DOES"));
  if (behavior.summary) console.log(behavior.summary);
  for (const b of behavior.behaviors || []) console.log(dim("  · ") + b);
  console.log("");

  console.log(bold(`FINDINGS (${findings.length})`));
  if (findings.length === 0) {
    console.log(dim("  none — the specimen behaves as declared across the cases examined"));
  }
  findings.forEach((f, i) => {
    const sev = (f.severity || "minor").toLowerCase();
    const sp = SEV_PAINT[sev] || dim;
    console.log("");
    console.log(`  ${bold(`F-${String(i + 1).padStart(2, "0")}`)}  ${sp(sev.toUpperCase())}  ${dim(f.location || "")}`);
    if (f.kind === "mismatch") {
      console.log(`      Declared: ${f.expected || ""}`);
      console.log(`      Observed: ${f.actual || ""}`);
    } else {
      console.log(`      ${f.title ? f.title + " — " : ""}${f.explanation || ""}`);
    }
    if (f.fix) console.log(`      Fix: ${f.fix}`);
  });
  console.log("");

  process.exit(v.exit);
}

main().catch((e) => {
  console.error("\n" + red("Inspection error: ") + (e && e.message ? e.message : String(e)));
  process.exit(3);
});
