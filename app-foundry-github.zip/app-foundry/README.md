# App Foundry 🏭

An autonomous agent system that hunts the internet for real problems, decides
which one is worth solving, builds a web app that solves it, deploys it live,
and emails you the URL. Runs in a continuous loop with hard money guardrails.

```
 every ~4h ┌─────────────────────────────────────────────────────────┐
 ┌────────►│ 4 SCOUTS (haiku, parallel)                              │
 │         │ reddit · hacker news · app store reviews · open web     │
 │         └──────────────────────┬──────────────────────────────────┘
 │                                ▼ raw pain points → SQLite
 │         ┌─────────────────────────────────────────────────────────┐
 │         │ ANALYST (sonnet) — dedupe vs. history, score 0-10       │
 │         │ quality bar 7.0 → most cycles ship NOTHING (on purpose) │
 │         └──────────────────────┬──────────────────────────────────┘
 │                                ▼ winner only
 │         ┌─────────────────────────────────────────────────────────┐
 │         │ SPEC (sonnet) — picks frontend vs fullstack, writes spec│
 │         └──────────────────────┬──────────────────────────────────┘
 │                                ▼
 │         ┌─────────────────────────────────────────────────────────┐
 │         │ BUILDER (agent sdk, $5 hard cap) ⇄ CRITIC (max 3 rounds)│
 │         └──────────────────────┬──────────────────────────────────┘
 │                                ▼ independent `npm run build` gate
 │         ┌─────────────────────────────────────────────────────────┐
 │         │ DEPLOY (vercel --prod) ──► 📧 email you the live URL    │
 └─────────┴─────────────────────────────────────────────────────────┘
   guardrails: $15/day ceiling · 2 ships/day · STOP-file kill switch
              · auto-pause after 3 consecutive build failures
```

## Prerequisites

- Python 3.10+
- Node.js 18+ and the Vercel CLI: `npm i -g vercel`
- Accounts/keys: Anthropic API, Vercel, Resend (or any SMTP login),
  and optionally one Supabase project (for full-stack apps)

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env        # then fill it in
```

`.env` notes:
- **VERCEL_TOKEN** — create at vercel.com → Settings → Tokens.
- **Email** — set `RESEND_API_KEY` *or* the `SMTP_*` block (Gmail app
  password works). Without either, ships only appear in logs.
- **Supabase (optional)** — create ONE project; all generated full-stack apps
  share it, each prefixing its tables (`my_app_*`). Skip it entirely and the
  system automatically builds frontend-only apps. (Upgrade path: per-app
  projects via the Supabase Management API.)

## Running

```bash
python -m foundry.main --once --dry-run   # 1 cycle, builds but doesn't deploy — START HERE
python -m foundry.main --once             # 1 full cycle incl. deploy
python -m foundry.main                    # the real thing: continuous loop
```

Run it long-term under `tmux`, `systemd`, or Docker — it's a single process.

## Run with Docker (optional)

The repo ships with a `Dockerfile` and `compose.yaml` that bundle Python,
Node 20, and the Vercel CLI:

```bash
docker compose up -d --build   # start the loop in the background
docker compose logs -f         # watch it hunt
touch STOP                     # kill switch works from the host too
docker compose down            # stop the container
```

State (`foundry.db`, `workspaces/`, `foundry.log`) stays on the host because
the project directory is bind-mounted.

## Saving to GitHub

```bash
git init
git add .
git commit -m "App Foundry: autonomous problem→app pipeline"
git branch -M main
git remote add origin https://github.com/<you>/app-foundry.git
git push -u origin main
```

(Or with the GitHub CLI: `gh repo create app-foundry --private --source=. --push`.)

`.gitignore` already excludes `.env`, `foundry.db`, `foundry.log`, and
`workspaces/` — **your keys and runtime state never reach the repo**. Double
check with `git status` before the first push: if you ever see `.env` listed,
stop and fix it. CI (`.github/workflows/ci.yml`) runs the smoke tests on every
push, so the green check tells you the pipeline logic is intact.

## Stopping it

```bash
touch STOP      # loop halts cleanly at the next checkpoint (≤30s)
rm STOP         # allow it to start again
```

Ctrl+C also works. The loop additionally **pauses itself** and emails you if
3 builds fail in a row.

## Money guardrails (config.yaml)

| Knob | Default | Meaning |
|---|---|---|
| `per_app_budget_usd` | 5.0 | hard cap of model spend per build |
| `daily_budget_usd` | 15.0 | ceiling across all activity per day |
| `max_ships_per_day` | 2 | even if budget remains |
| `quality_bar` | 7.0 | min weighted score (0-10) to build anything |

The builder cap is enforced between bounded agent sessions (build → critic →
fix), each with its own turn limit — no single session can run away. All
spend is written to the `spend` table in `foundry.db`.

## Inspecting what it's doing

- `tail -f foundry.log` — live narration of every cycle
- `sqlite3 foundry.db 'SELECT title, score, status FROM ideas ORDER BY id DESC LIMIT 20;'`
- `sqlite3 foundry.db 'SELECT scope, status, spend_usd, url FROM builds;'`
- Generated codebases live in `workspaces/` (failed ones are kept for autopsy,
  minus `node_modules`)

## Tuning the brain

All agent behavior lives in `foundry/agents/prompts.py` — scoring weights,
what scouts hunt for, build quality rules. `config.yaml` has the knobs:
narrow the hunt with `niche_focus: "small business tools"`, slow the loop
with `cycle_hours`, raise `quality_bar` to ship less and better.

## Troubleshooting

- **`vercel CLI not found`** — `npm i -g vercel`, ensure it's on PATH for the
  process running the loop.
- **Nothing ever ships** — working as designed if scores hover below the bar;
  check `ideas` in the db. Lower `quality_bar` to 6 if you want more volume.
- **Builds fail repeatedly** — read the newest `workspaces/*/` and the `log`
  column in `builds`. Often a Node version issue: use Node 18/20 LTS.
- **SDK errors on start** — the Agent SDK is young and moves fast; it's pinned
  to `0.2.x` in requirements. If an upgrade breaks message parsing, the
  duck-typing in `foundry/agents/runner.py` is the file to adjust.

## Honest expectations

This ships *v1s of small, focused apps* — the kind one strong engineer could
build in a day — not venture-scale products. The quality bar is your friend:
a system that ships two good apps a week beats one that ships junk daily.
You are responsible for what it deploys under your Vercel account; glance at
the email, click the URL, and delete anything you don't want live.
