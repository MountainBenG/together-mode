"""Smoke test — verifies config, db, budget logic, prompts, JSON parsing,
and Agent SDK option compatibility WITHOUT making any API calls.

Run directly (CI does):  python tests/smoke_test.py
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

# Fake credentials BEFORE any foundry import (config validates on load).
os.environ.setdefault("ANTHROPIC_API_KEY", "sk-test")
os.environ.setdefault("VERCEL_TOKEN", "tok-test")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from foundry.config import CONFIG  # noqa: E402
from foundry import db, budget  # noqa: E402
from foundry.agents import prompts  # noqa: E402
from foundry.agents.runner import extract_json  # noqa: E402
from foundry.agents.spec import _slugify  # noqa: E402
from foundry import deploy, notify, main  # noqa: E402, F401 — import side check
from claude_agent_sdk import ClaudeAgentOptions  # noqa: E402


def test_config() -> None:
    assert CONFIG.per_app_budget_usd > 0
    assert 0 < CONFIG.quality_bar <= 10
    assert CONFIG.sources, "at least one scout source required"


def test_db_and_budget() -> None:
    db.DB_PATH = Path(tempfile.mkdtemp()) / "test.db"
    db.init()

    assert db.spend_today() == 0 and db.ships_today() == 0
    ok, _ = budget.can_start_build()
    assert ok

    db.add_problems([{"source": "reddit", "evidence_url": "u", "summary": "s"}])
    iid = db.add_idea(
        {"title": "Test Idea", "summary": "x", "score": 8.1, "breakdown": {}, "rationale": "r"},
        passed=True,
    )
    assert db.past_idea_titles() == ["Test Idea"]

    bid = db.add_build(iid, "frontend", "ws")
    db.finish_build(bid, status="shipped", spend=3.2, url="https://x.vercel.app")
    db.add_spend(3.2)
    db.add_spend(1.0)
    assert abs(db.spend_today() - 4.2) < 1e-9
    assert db.ships_today() == 1
    assert abs(budget.daily_budget_left() - (CONFIG.daily_budget_usd - 4.2)) < 1e-9

    bid2 = db.add_build(iid, "frontend", "ws2")
    db.finish_build(bid2, status="failed", spend=1.0)
    assert db.consecutive_failures() == 1


def test_prompts_format() -> None:
    for source, where in prompts.SCOUT_TARGETS.items():
        p = prompts.SCOUT_BASE.format(
            niche="any", where=where, source=source, json_rules=prompts.JSON_RULES
        )
        assert len(p) > 200
    a = prompts.ANALYST.format(
        budget="5", bar=7.0, json_rules=prompts.JSON_RULES, findings="[]", past_titles="[]"
    )
    s = prompts.SPEC.format(
        budget="5", fullstack_note=prompts.SPEC_NO_FULLSTACK, prefix="t",
        json_rules=prompts.JSON_RULES, idea="{}",
    )
    c = prompts.CRITIC.format(json_rules=prompts.JSON_RULES)
    f = prompts.FIXER.format(issues="- x")
    assert all(len(x) > 100 for x in (a, s, c)) and len(f) > 50


def test_json_extraction() -> None:
    assert extract_json('hi ```json\n{"a": 1}\n``` bye') == {"a": 1}
    assert extract_json('{"b": [1, 2]}') == {"b": [1, 2]}
    assert extract_json("no json here") == {}


def test_sdk_options_compat() -> None:
    """Every kwarg runner.py passes must be accepted by the installed SDK."""
    ClaudeAgentOptions(
        model="m", system_prompt="s", allowed_tools=["WebSearch"],
        permission_mode="bypassPermissions", cwd="/tmp", max_turns=5, env={},
    )


def test_slugify() -> None:
    assert _slugify("My Cool App!!") == "my-cool-app"
    assert _slugify("???") == "foundry-app"


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted({k: v for k, v in globals().items() if k.startswith("test_")}.items()):
        try:
            fn()
            print(f"  ✅ {name}")
        except AssertionError as e:
            failures += 1
            print(f"  ❌ {name}: {e}")
    if failures:
        sys.exit(f"{failures} test(s) failed")
    print("ALL SMOKE TESTS PASSED")
