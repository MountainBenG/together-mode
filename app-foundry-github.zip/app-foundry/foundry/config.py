"""Configuration: merges config.yaml with .env, validates what's required."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")


@dataclass
class Config:
    cycle_hours: float = 4
    per_app_budget_usd: float = 5.0
    daily_budget_usd: float = 15.0
    max_ships_per_day: int = 2
    quality_bar: float = 7.0
    max_fix_rounds: int = 3
    builder_max_turns: int = 80
    max_consecutive_failures: int = 3
    scout_model: str = "claude-haiku-4-5"
    core_model: str = "claude-sonnet-4-6"
    sources: list[str] = field(default_factory=lambda: ["reddit", "hackernews", "app_reviews", "web"])
    niche_focus: str = ""
    workspace_dir: Path = ROOT / "workspaces"

    # env-sourced
    anthropic_key: str = ""
    vercel_token: str = ""
    notify_email: str = ""
    notify_from: str = ""
    resend_key: str = ""
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_pass: str = ""
    supabase_url: str = ""
    supabase_anon_key: str = ""
    supabase_service_key: str = ""

    @property
    def fullstack_enabled(self) -> bool:
        return bool(self.supabase_url and self.supabase_anon_key)

    @property
    def email_enabled(self) -> bool:
        return bool(self.notify_email and (self.resend_key or self.smtp_host))


def load() -> Config:
    cfg = Config()
    yml_path = ROOT / "config.yaml"
    if yml_path.exists():
        data = yaml.safe_load(yml_path.read_text()) or {}
        cfg.cycle_hours = float(data.get("cycle_hours", cfg.cycle_hours))
        cfg.per_app_budget_usd = float(data.get("per_app_budget_usd", cfg.per_app_budget_usd))
        cfg.daily_budget_usd = float(data.get("daily_budget_usd", cfg.daily_budget_usd))
        cfg.max_ships_per_day = int(data.get("max_ships_per_day", cfg.max_ships_per_day))
        cfg.quality_bar = float(data.get("quality_bar", cfg.quality_bar))
        cfg.max_fix_rounds = int(data.get("max_fix_rounds", cfg.max_fix_rounds))
        cfg.builder_max_turns = int(data.get("builder_max_turns", cfg.builder_max_turns))
        cfg.max_consecutive_failures = int(data.get("max_consecutive_failures", cfg.max_consecutive_failures))
        models = data.get("models", {})
        cfg.scout_model = models.get("scout", cfg.scout_model)
        cfg.core_model = models.get("core", cfg.core_model)
        cfg.sources = list(data.get("sources", cfg.sources))
        cfg.niche_focus = str(data.get("niche_focus") or "")
        cfg.workspace_dir = ROOT / str(data.get("workspace_dir", "workspaces"))

    cfg.anthropic_key = os.getenv("ANTHROPIC_API_KEY", "")
    cfg.vercel_token = os.getenv("VERCEL_TOKEN", "")
    cfg.notify_email = os.getenv("NOTIFY_EMAIL", "")
    cfg.notify_from = os.getenv("NOTIFY_FROM", "foundry@localhost")
    cfg.resend_key = os.getenv("RESEND_API_KEY", "")
    cfg.smtp_host = os.getenv("SMTP_HOST", "")
    cfg.smtp_port = int(os.getenv("SMTP_PORT", "587") or 587)
    cfg.smtp_user = os.getenv("SMTP_USER", "")
    cfg.smtp_pass = os.getenv("SMTP_PASS", "")
    cfg.supabase_url = os.getenv("SUPABASE_URL", "")
    cfg.supabase_anon_key = os.getenv("SUPABASE_ANON_KEY", "")
    cfg.supabase_service_key = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")

    missing = []
    if not cfg.anthropic_key:
        missing.append("ANTHROPIC_API_KEY")
    if not cfg.vercel_token:
        missing.append("VERCEL_TOKEN")
    if missing:
        raise SystemExit(f"Missing required env vars: {', '.join(missing)} — copy .env.example to .env and fill it in.")
    return cfg


CONFIG = load()
