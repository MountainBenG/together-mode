"""App Foundry — the continuous loop.

    python -m foundry.main            # run forever (Ctrl+C or `touch STOP` to stop)
    python -m foundry.main --once     # single cycle, then exit
    python -m foundry.main --dry-run  # full pipeline but skip the real deploy

Pipeline per cycle:
    scouts -> analyst (quality bar) -> spec -> build+critic -> deploy -> email
Most cycles correctly end at the quality bar with nothing shipped.
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import sys
import time

from . import budget, db, deploy, notify
from .agents import analyst, builder, scouts, spec
from .config import CONFIG, ROOT

log = logging.getLogger("foundry")


def setup_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)-16s %(levelname)-7s %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(ROOT / "foundry.log"),
        ],
    )


async def run_cycle(dry_run: bool = False) -> None:
    budget.guard()

    ok, reason = budget.can_start_build()
    if not ok:
        log.info("Cycle skipped before scouting: %s", reason)
        if db.consecutive_failures() >= CONFIG.max_consecutive_failures:
            notify.failure_email(reason)
            raise budget.Halt(reason)
        return

    # ── 1. Scout ──────────────────────────────────────────
    log.info("── Scouting (%s) ──", ", ".join(CONFIG.sources))
    findings, cost = await scouts.run_scouts()
    budget.record(cost)
    log.info("Scouts returned %d findings ($%.2f)", len(findings), cost)
    budget.guard()
    if not findings:
        log.info("Nothing found this cycle.")
        return

    # ── 2. Analyse + quality bar ─────────────────────────
    winner, cost = await analyst.pick_winner(findings)
    budget.record(cost)
    budget.guard()
    if winner is None:
        log.info("No idea cleared the %.1f bar — correctly shipping nothing.", CONFIG.quality_bar)
        return
    log.info("WINNER (%.1f/10): %s", winner.get("score", 0), winner.get("title"))

    if budget.daily_budget_left() < CONFIG.per_app_budget_usd:
        log.info("Winner found but daily budget can't cover a build — deferring.")
        return

    # ── 3. Spec ──────────────────────────────────────────
    the_spec, cost = await spec.write_spec(winner)
    budget.record(cost)
    budget.guard()
    if the_spec is None:
        db.set_idea_status(winner["db_id"], "failed")
        return
    db.set_idea_status(winner["db_id"], "specced")

    # ── 4. Build + critic loop ───────────────────────────
    build_id = db.add_build(winner["db_id"], the_spec["scope"], "")
    db.set_idea_status(winner["db_id"], "building")
    result = await builder.build_app(the_spec)
    budget.record(result.cost_usd)

    if not result.ok:
        db.finish_build(build_id, status="failed", spend=result.cost_usd, log="\n".join(result.log))
        db.set_idea_status(winner["db_id"], "failed")
        builder.cleanup_failed(result.workspace)
        if db.consecutive_failures() >= CONFIG.max_consecutive_failures:
            reason = f"{CONFIG.max_consecutive_failures} builds failed in a row. Loop pausing."
            notify.failure_email(reason)
            raise budget.Halt(reason)
        return
    budget.guard()

    # ── 5. Independent gate + deploy ─────────────────────
    gate_ok, gate_msg = deploy.final_gate(result.workspace)
    if not gate_ok:
        log.error("Final gate failed: %s", gate_msg)
        db.finish_build(build_id, status="failed", spend=result.cost_usd, log=gate_msg)
        db.set_idea_status(winner["db_id"], "failed")
        return

    if dry_run:
        log.info("DRY RUN — skipping deploy. App ready at %s", result.workspace)
        db.finish_build(build_id, status="built", spend=result.cost_usd,
                        log="\n".join(result.log))
        db.set_idea_status(winner["db_id"], "built")
        return

    url, dlog = deploy.deploy(result.workspace, the_spec["scope"])
    if not url:
        log.error("Deploy failed: %s", dlog[:500])
        db.finish_build(build_id, status="failed", spend=result.cost_usd, log=dlog)
        db.set_idea_status(winner["db_id"], "failed")
        return

    # ── 6. Shipped 🎉 ────────────────────────────────────
    db.finish_build(build_id, status="shipped", spend=result.cost_usd, url=url,
                    log="\n".join(result.log))
    db.set_idea_status(winner["db_id"], "shipped")
    log.info("SHIPPED %s -> %s ($%.2f)", the_spec["app_slug"], url, result.cost_usd)
    notify.ship_email(winner, url, the_spec["scope"], result.cost_usd)


def killable_sleep(seconds: float) -> None:
    """Sleep in 30s slices so `touch STOP` works mid-wait."""
    end = time.time() + seconds
    while time.time() < end:
        if budget.kill_switch_active():
            raise budget.Halt("Kill switch activated during sleep.")
        time.sleep(min(30, max(0, end - time.time())))


def main() -> None:
    parser = argparse.ArgumentParser(description="App Foundry — autonomous problem→app loop")
    parser.add_argument("--once", action="store_true", help="run a single cycle and exit")
    parser.add_argument("--dry-run", action="store_true", help="build but skip the real deploy")
    args = parser.parse_args()

    setup_logging()
    db.init()
    CONFIG.workspace_dir.mkdir(exist_ok=True)
    log.info(
        "App Foundry up. cap=$%.2f/app, $%.2f/day, %d ships/day, bar=%.1f, cycle=%.1fh%s",
        CONFIG.per_app_budget_usd, CONFIG.daily_budget_usd, CONFIG.max_ships_per_day,
        CONFIG.quality_bar, CONFIG.cycle_hours, " [DRY RUN]" if args.dry_run else "",
    )
    if not CONFIG.email_enabled:
        log.warning("Email isn't configured — ships will only appear in logs/db.")
    if not CONFIG.fullstack_enabled:
        log.warning("Supabase not configured — all apps will be frontend-only.")

    try:
        while True:
            try:
                asyncio.run(run_cycle(dry_run=args.dry_run))
            except budget.Halt:
                raise
            except Exception:  # noqa: BLE001 — one bad cycle must not kill the loop
                log.exception("Cycle crashed; continuing to next cycle.")
            if args.once:
                break
            log.info("Sleeping %.1fh until next cycle…", CONFIG.cycle_hours)
            killable_sleep(CONFIG.cycle_hours * 3600)
    except (budget.Halt, KeyboardInterrupt) as e:
        log.info("Shutting down: %s", e or "Ctrl+C")


if __name__ == "__main__":
    main()
