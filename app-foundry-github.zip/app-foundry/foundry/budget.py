"""Guardrails: spend caps, ship limits, and the kill switch.

Kill switch: create a file named STOP in the project root —
    touch STOP
The loop checks for it between every phase and shuts down cleanly.
Delete the file to allow restarts.
"""
from __future__ import annotations

from .config import CONFIG, ROOT
from . import db

STOP_FILE = ROOT / "STOP"


class Halt(Exception):
    """Raised when the kill switch or a hard cap stops the run."""


def kill_switch_active() -> bool:
    return STOP_FILE.exists()


def guard() -> None:
    """Call between phases. Raises Halt if the kill switch is on."""
    if kill_switch_active():
        raise Halt("Kill switch (STOP file) is active.")


def daily_budget_left() -> float:
    return max(0.0, CONFIG.daily_budget_usd - db.spend_today())


def can_start_build() -> tuple[bool, str]:
    """Cheap pre-flight before committing to an expensive build."""
    if db.ships_today() >= CONFIG.max_ships_per_day:
        return False, f"Daily ship limit reached ({CONFIG.max_ships_per_day})."
    if daily_budget_left() < CONFIG.per_app_budget_usd * 0.5:
        return False, (
            f"Daily budget nearly exhausted (${daily_budget_left():.2f} left, "
            f"builds need up to ${CONFIG.per_app_budget_usd:.2f})."
        )
    if db.consecutive_failures() >= CONFIG.max_consecutive_failures:
        return False, (
            f"{CONFIG.max_consecutive_failures} consecutive build failures — "
            "loop paused for safety. Investigate, then delete/fix and restart."
        )
    return True, ""


def record(usd: float | None) -> None:
    if usd:
        db.add_spend(float(usd))
