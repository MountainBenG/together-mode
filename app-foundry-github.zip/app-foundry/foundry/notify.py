"""Email notifications. Resend if RESEND_API_KEY is set, else SMTP.

Never crashes the loop — failures are logged and swallowed.
"""
from __future__ import annotations

import logging
import smtplib
from email.mime.text import MIMEText

import httpx

from .config import CONFIG

log = logging.getLogger("foundry.notify")


def send(subject: str, body: str) -> None:
    if not CONFIG.email_enabled:
        log.warning("Email not configured — would have sent: %s", subject)
        return
    try:
        if CONFIG.resend_key:
            _send_resend(subject, body)
        else:
            _send_smtp(subject, body)
        log.info("Emailed: %s", subject)
    except Exception:  # noqa: BLE001 — notification must never kill the loop
        log.exception("Email failed for: %s", subject)


def _send_resend(subject: str, body: str) -> None:
    r = httpx.post(
        "https://api.resend.com/emails",
        headers={"Authorization": f"Bearer {CONFIG.resend_key}"},
        json={
            "from": CONFIG.notify_from,
            "to": [CONFIG.notify_email],
            "subject": subject,
            "text": body,
        },
        timeout=30,
    )
    r.raise_for_status()


def _send_smtp(subject: str, body: str) -> None:
    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = CONFIG.notify_from
    msg["To"] = CONFIG.notify_email
    with smtplib.SMTP(CONFIG.smtp_host, CONFIG.smtp_port, timeout=30) as s:
        s.starttls()
        if CONFIG.smtp_user:
            s.login(CONFIG.smtp_user, CONFIG.smtp_pass)
        s.sendmail(CONFIG.notify_from, [CONFIG.notify_email], msg.as_string())


def ship_email(idea: dict, url: str, scope: str, cost: float) -> None:
    send(
        f"🚀 Foundry shipped: {idea.get('title', 'New app')}",
        f"""Your agent system just shipped an app.

App: {idea.get('title')}
Live URL: {url}
Scope: {scope}
Build cost: ${cost:.2f}

The problem it solves:
{idea.get('summary')}

Why it cleared the quality bar:
{idea.get('rationale', 'n/a')}

— App Foundry
""",
    )


def failure_email(reason: str) -> None:
    send("⚠️ Foundry paused", f"The loop paused itself:\n\n{reason}\n\n— App Foundry")
