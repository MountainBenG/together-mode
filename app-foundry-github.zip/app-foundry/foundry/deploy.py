"""Deploy: final compile gate, then `vercel --prod` with env injection."""
from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path

from .config import CONFIG

log = logging.getLogger("foundry.deploy")


def _run(cmd: list[str], cwd: Path, timeout: int = 900) -> subprocess.CompletedProcess:
    log.info("$ %s", " ".join(cmd[:6]) + (" …" if len(cmd) > 6 else ""))
    return subprocess.run(
        cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout
    )


def final_gate(workspace: Path) -> tuple[bool, str]:
    """Independent `npm run build` — never trust an agent's word alone."""
    if not (workspace / "node_modules").exists():
        install = _run(["npm", "install", "--no-audit", "--no-fund"], workspace)
        if install.returncode != 0:
            return False, f"npm install failed:\n{install.stderr[-2000:]}"
    build = _run(["npm", "run", "build"], workspace)
    if build.returncode != 0:
        return False, f"npm run build failed:\n{(build.stderr or build.stdout)[-2000:]}"
    return True, "build clean"


def deploy(workspace: Path, scope: str) -> tuple[str, str]:
    """Returns (url, log). Empty url means failure."""
    cmd = [
        "vercel", "deploy", "--prod", "--yes",
        "--token", CONFIG.vercel_token,
    ]
    if scope == "fullstack":
        for key, val in (
            ("NEXT_PUBLIC_SUPABASE_URL", CONFIG.supabase_url),
            ("NEXT_PUBLIC_SUPABASE_ANON_KEY", CONFIG.supabase_anon_key),
        ):
            cmd += ["--env", f"{key}={val}", "--build-env", f"{key}={val}"]

    try:
        proc = _run(cmd, workspace, timeout=1200)
    except subprocess.TimeoutExpired:
        return "", "vercel deploy timed out"
    except FileNotFoundError:
        return "", "vercel CLI not found — `npm i -g vercel` and ensure it's on PATH"

    out = (proc.stdout or "") + "\n" + (proc.stderr or "")
    if proc.returncode != 0:
        return "", f"vercel exited {proc.returncode}:\n{out[-2000:]}"

    urls = re.findall(r"https://[^\s]+\.vercel\.app", out)
    return (urls[-1] if urls else ""), out[-2000:]
