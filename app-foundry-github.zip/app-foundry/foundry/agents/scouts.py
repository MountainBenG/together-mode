"""Scouts: one agent per source, run in parallel, web search only."""
from __future__ import annotations

import asyncio
import logging

from .. import db
from ..config import CONFIG
from . import prompts
from .runner import extract_json, run_agent

log = logging.getLogger("foundry.scouts")


async def _scout(source: str) -> tuple[list[dict], float]:
    niche = (
        f"Focus the hunt on this niche: {CONFIG.niche_focus}."
        if CONFIG.niche_focus
        else "Hunt across any niche."
    )
    prompt = prompts.SCOUT_BASE.format(
        niche=niche,
        where=prompts.SCOUT_TARGETS[source],
        source=source,
        json_rules=prompts.JSON_RULES,
    )
    res = await run_agent(
        prompt,
        model=CONFIG.scout_model,
        tools=["WebSearch", "WebFetch"],
        max_turns=15,
    )
    data = extract_json(res.text)
    problems = [p for p in data.get("problems", []) if p.get("summary")]
    for p in problems:
        p["source"] = source
    log.info("Scout[%s]: %d findings ($%.3f)", source, len(problems), res.cost_usd)
    return problems, res.cost_usd


async def run_scouts() -> tuple[list[dict], float]:
    """Run all enabled scouts in parallel. Returns (findings, total_cost)."""
    sources = [s for s in CONFIG.sources if s in prompts.SCOUT_TARGETS]
    results = await asyncio.gather(*(_scout(s) for s in sources), return_exceptions=True)

    findings: list[dict] = []
    cost = 0.0
    for src, r in zip(sources, results):
        if isinstance(r, Exception):
            log.error("Scout[%s] crashed: %s", src, r)
            continue
        probs, c = r
        findings.extend(probs)
        cost += c

    if findings:
        db.add_problems(findings)
    return findings, cost
