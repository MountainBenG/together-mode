"""Builder: an Agent SDK coding session with a critic loop and a hard $ cap.

Budget enforcement model: the SDK reports cost when a session ends, so the
cap is enforced *between* bounded sessions (build -> critic -> fix -> ...).
Each session has max_turns, so no single session can run away. If cumulative
cost crosses the per-app cap, we stop where we are.
"""
from __future__ import annotations

import logging
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path

from ..config import CONFIG
from . import prompts
from .runner import extract_json, run_agent

log = logging.getLogger("foundry.builder")

BUILD_TOOLS = ["Bash", "Read", "Write", "Edit", "Glob", "Grep"]
CRITIC_TOOLS = ["Bash", "Read", "Glob", "Grep"]


@dataclass
class BuildResult:
    ok: bool
    workspace: Path
    cost_usd: float = 0.0
    scope: str = "frontend"
    log: list[str] = field(default_factory=list)

    def note(self, msg: str) -> None:
        self.log.append(msg)
        log.info(msg)


def _app_env(scope: str) -> dict[str, str]:
    if scope != "fullstack":
        return {}
    return {
        "NEXT_PUBLIC_SUPABASE_URL": CONFIG.supabase_url,
        "NEXT_PUBLIC_SUPABASE_ANON_KEY": CONFIG.supabase_anon_key,
    }


async def build_app(spec: dict) -> BuildResult:
    slug = spec["app_slug"]
    workspace = CONFIG.workspace_dir / f"{slug}-{int(time.time())}"
    workspace.mkdir(parents=True, exist_ok=True)
    (workspace / "SPEC.md").write_text(spec["spec_markdown"])

    result = BuildResult(ok=False, workspace=workspace, scope=spec["scope"])
    cap = CONFIG.per_app_budget_usd
    env = _app_env(spec["scope"])

    # ── Session 1: build ─────────────────────────────────
    result.note(f"Build started in {workspace.name} (cap ${cap:.2f})")
    build = await run_agent(
        "Read SPEC.md in this directory and build the app per your system rules.",
        system=prompts.BUILDER_SYSTEM,
        model=CONFIG.core_model,
        tools=BUILD_TOOLS,
        cwd=workspace,
        max_turns=CONFIG.builder_max_turns,
        env=env,
    )
    result.cost_usd += build.cost_usd
    result.note(f"Build session done (${build.cost_usd:.2f}, total ${result.cost_usd:.2f})")
    if build.is_error:
        result.note("Build session ended in error state.")
    if result.cost_usd >= cap:
        result.note("Budget cap hit after build session — skipping critic loop.")

    # ── Critic / fix loop ────────────────────────────────
    rounds = 0
    while result.cost_usd < cap and rounds < CONFIG.max_fix_rounds:
        critic = await run_agent(
            prompts.CRITIC.format(json_rules=prompts.JSON_RULES),
            model=CONFIG.core_model,
            tools=CRITIC_TOOLS,
            cwd=workspace,
            max_turns=20,
            env=env,
        )
        result.cost_usd += critic.cost_usd
        verdict = extract_json(critic.text)
        issues = verdict.get("issues", [])
        result.note(
            f"Critic round {rounds + 1}: {verdict.get('verdict', '?')} "
            f"({len(issues)} issues, total ${result.cost_usd:.2f})"
        )

        if verdict.get("verdict") == "pass":
            result.ok = True
            break
        if result.cost_usd >= cap:
            result.note("Budget cap hit before fixes could run.")
            break

        rounds += 1
        fixer = await run_agent(
            prompts.FIXER.format(issues="\n".join(f"- {i}" for i in issues) or "- build is failing"),
            system=prompts.BUILDER_SYSTEM,
            model=CONFIG.core_model,
            tools=BUILD_TOOLS,
            cwd=workspace,
            max_turns=40,
            env=env,
        )
        result.cost_usd += fixer.cost_usd
        result.note(f"Fix round {rounds} done (total ${result.cost_usd:.2f})")

    if not result.ok:
        result.note("Build did NOT pass the critic within budget.")
    return result


def cleanup_failed(workspace: Path) -> None:
    """Failed builds keep their workspace for inspection; node_modules is pruned to save disk."""
    nm = workspace / "node_modules"
    if nm.exists():
        shutil.rmtree(nm, ignore_errors=True)
