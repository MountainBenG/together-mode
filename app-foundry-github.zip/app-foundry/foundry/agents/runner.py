"""Thin wrapper around the Claude Agent SDK.

Every agent in the system funnels through run_agent(), which returns the
final text plus the dollar cost the SDK reports — that cost feeds the
budget ledger. Message types are duck-typed by class name so minor SDK
version bumps don't break us.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path

from claude_agent_sdk import ClaudeAgentOptions, query

log = logging.getLogger("foundry.runner")


@dataclass
class AgentResult:
    text: str
    cost_usd: float
    is_error: bool


async def run_agent(
    prompt: str,
    *,
    system: str | None = None,
    model: str,
    tools: list[str] | None = None,
    cwd: Path | None = None,
    max_turns: int = 25,
    env: dict[str, str] | None = None,
) -> AgentResult:
    opts = ClaudeAgentOptions(
        model=model,
        system_prompt=system,
        allowed_tools=tools or [],
        permission_mode="bypassPermissions",  # fully autonomous by design
        cwd=str(cwd) if cwd else None,
        max_turns=max_turns,
        env=env or {},
    )

    text_parts: list[str] = []
    cost = 0.0
    is_error = False

    async for msg in query(prompt=prompt, options=opts):
        kind = type(msg).__name__
        if kind == "AssistantMessage":
            for block in getattr(msg, "content", []) or []:
                if type(block).__name__ == "TextBlock":
                    text_parts.append(getattr(block, "text", ""))
        elif kind == "ResultMessage":
            cost = float(getattr(msg, "total_cost_usd", 0) or 0)
            is_error = bool(getattr(msg, "is_error", False))

    return AgentResult(text="\n".join(text_parts).strip(), cost_usd=cost, is_error=is_error)


def extract_json(text: str) -> dict:
    """Pull the first JSON object out of a response, fenced or bare."""
    fenced = re.search(r"```json\s*(\{.*?\})\s*```", text, re.DOTALL)
    candidates = [fenced.group(1)] if fenced else []
    brace = re.search(r"\{.*\}", text, re.DOTALL)
    if brace:
        candidates.append(brace.group(0))
    for c in candidates:
        try:
            return json.loads(c)
        except json.JSONDecodeError:
            continue
    log.warning("No parseable JSON in agent output (first 300 chars): %s", text[:300])
    return {}
