"""Analyst: clusters findings, scores ideas, enforces the quality bar."""
from __future__ import annotations

import json
import logging

from .. import db
from ..config import CONFIG
from . import prompts
from .runner import extract_json, run_agent

log = logging.getLogger("foundry.analyst")


async def pick_winner(findings: list[dict]) -> tuple[dict | None, float]:
    """Score this cycle's findings. Returns (winning idea w/ db id, cost) or (None, cost)."""
    if not findings:
        return None, 0.0

    prompt = prompts.ANALYST.format(
        budget=f"{CONFIG.per_app_budget_usd:.0f}",
        bar=CONFIG.quality_bar,
        json_rules=prompts.JSON_RULES,
        findings=json.dumps(findings, indent=1)[:14000],
        past_titles=json.dumps(db.past_idea_titles(), indent=0),
    )
    res = await run_agent(
        prompt,
        model=CONFIG.core_model,
        tools=["WebSearch"],  # brief competition checks allowed
        max_turns=12,
    )
    ideas = extract_json(res.text).get("ideas", [])

    winner: dict | None = None
    for idea in sorted(ideas, key=lambda i: float(i.get("score", 0)), reverse=True):
        score = float(idea.get("score", 0))
        passed = score >= CONFIG.quality_bar
        idea_id = db.add_idea(idea, passed)
        log.info("Idea %.1f/10 [%s]: %s", score, "PASS" if passed else "reject", idea.get("title"))
        if passed and winner is None:
            idea["db_id"] = idea_id
            winner = idea

    return winner, res.cost_usd
