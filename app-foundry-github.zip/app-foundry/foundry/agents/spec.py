"""Spec writer: winning idea -> precise build spec + frontend/fullstack decision."""
from __future__ import annotations

import json
import logging
import re

from ..config import CONFIG
from . import prompts
from .runner import extract_json, run_agent

log = logging.getLogger("foundry.spec")


def _slugify(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return s[:40] or "foundry-app"


async def write_spec(idea: dict) -> tuple[dict | None, float]:
    """Returns ({scope, app_slug, spec_markdown}, cost) or (None, cost)."""
    prefix = _slugify(idea.get("title", "app")).replace("-", "_")[:24]
    prompt = prompts.SPEC.format(
        budget=f"{CONFIG.per_app_budget_usd:.0f}",
        fullstack_note="" if CONFIG.fullstack_enabled else prompts.SPEC_NO_FULLSTACK,
        prefix=prefix,
        json_rules=prompts.JSON_RULES,
        idea=json.dumps(idea, indent=1),
    )
    res = await run_agent(prompt, model=CONFIG.core_model, max_turns=6)
    data = extract_json(res.text)

    scope = data.get("scope")
    spec_md = data.get("spec_markdown", "")
    if scope not in ("frontend", "fullstack") or len(spec_md) < 200:
        log.error("Spec agent returned an unusable spec.")
        return None, res.cost_usd
    if scope == "fullstack" and not CONFIG.fullstack_enabled:
        log.warning("Spec chose fullstack but Supabase isn't configured — forcing frontend.")
        scope = "frontend"

    data["scope"] = scope
    data["app_slug"] = _slugify(data.get("app_slug") or idea.get("title", "app"))
    data["table_prefix"] = prefix
    log.info("Spec ready: %s (%s)", data["app_slug"], scope)
    return data, res.cost_usd
