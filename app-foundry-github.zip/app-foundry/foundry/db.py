"""SQLite memory. Everything the system finds, decides, builds, and spends."""
from __future__ import annotations

import json
import sqlite3
from datetime import date, datetime
from pathlib import Path

from .config import ROOT

DB_PATH = ROOT / "foundry.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS problems (
    id INTEGER PRIMARY KEY,
    source TEXT, url TEXT, summary TEXT,
    found_at TEXT
);
CREATE TABLE IF NOT EXISTS ideas (
    id INTEGER PRIMARY KEY,
    title TEXT, summary TEXT,
    score REAL, breakdown TEXT, rationale TEXT,
    status TEXT,              -- rejected | passed | specced | building | shipped | failed
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS builds (
    id INTEGER PRIMARY KEY,
    idea_id INTEGER, scope TEXT,
    spend_usd REAL DEFAULT 0, status TEXT,
    url TEXT, workspace TEXT, log TEXT,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS spend (
    day TEXT PRIMARY KEY,
    usd REAL DEFAULT 0
);
"""


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init() -> None:
    with _conn() as c:
        c.executescript(SCHEMA)


def now() -> str:
    return datetime.utcnow().isoformat(timespec="seconds")


# ── problems ──────────────────────────────────────────────
def add_problems(items: list[dict]) -> None:
    with _conn() as c:
        c.executemany(
            "INSERT INTO problems (source, url, summary, found_at) VALUES (?,?,?,?)",
            [(p.get("source", ""), p.get("evidence_url", ""), p.get("summary", ""), now()) for p in items],
        )


# ── ideas ─────────────────────────────────────────────────
def past_idea_titles(limit: int = 200) -> list[str]:
    with _conn() as c:
        rows = c.execute(
            "SELECT title FROM ideas ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    return [r["title"] for r in rows]


def add_idea(idea: dict, passed: bool) -> int:
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO ideas (title, summary, score, breakdown, rationale, status, created_at) VALUES (?,?,?,?,?,?,?)",
            (
                idea.get("title", "untitled"),
                idea.get("summary", ""),
                float(idea.get("score", 0)),
                json.dumps(idea.get("breakdown", {})),
                idea.get("rationale", ""),
                "passed" if passed else "rejected",
                now(),
            ),
        )
        return int(cur.lastrowid)


def set_idea_status(idea_id: int, status: str) -> None:
    with _conn() as c:
        c.execute("UPDATE ideas SET status=? WHERE id=?", (status, idea_id))


# ── builds ────────────────────────────────────────────────
def add_build(idea_id: int, scope: str, workspace: str) -> int:
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO builds (idea_id, scope, status, workspace, created_at) VALUES (?,?,?,?,?)",
            (idea_id, scope, "building", workspace, now()),
        )
        return int(cur.lastrowid)


def finish_build(build_id: int, *, status: str, spend: float, url: str = "", log: str = "") -> None:
    with _conn() as c:
        c.execute(
            "UPDATE builds SET status=?, spend_usd=?, url=?, log=? WHERE id=?",
            (status, spend, url, log[-8000:], build_id),
        )


def ships_today() -> int:
    today = date.today().isoformat()
    with _conn() as c:
        row = c.execute(
            "SELECT COUNT(*) AS n FROM builds WHERE status='shipped' AND created_at LIKE ?",
            (f"{today}%",),
        ).fetchone()
    return int(row["n"])


def consecutive_failures() -> int:
    with _conn() as c:
        rows = c.execute("SELECT status FROM builds ORDER BY id DESC LIMIT 10").fetchall()
    n = 0
    for r in rows:
        if r["status"] == "failed":
            n += 1
        else:
            break
    return n


# ── spend ledger ──────────────────────────────────────────
def add_spend(usd: float) -> None:
    if usd <= 0:
        return
    today = date.today().isoformat()
    with _conn() as c:
        c.execute(
            "INSERT INTO spend (day, usd) VALUES (?,?) "
            "ON CONFLICT(day) DO UPDATE SET usd = usd + excluded.usd",
            (today, usd),
        )


def spend_today() -> float:
    today = date.today().isoformat()
    with _conn() as c:
        row = c.execute("SELECT usd FROM spend WHERE day=?", (today,)).fetchone()
    return float(row["usd"]) if row else 0.0
